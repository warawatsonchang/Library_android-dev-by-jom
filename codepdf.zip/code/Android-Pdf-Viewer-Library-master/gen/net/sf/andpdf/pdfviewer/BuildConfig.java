/** Automatically generated file. DO NOT MODIFY */
package net.sf.andpdf.pdfviewer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}